package ejercicioconductores;
public class Conductor implements FiltroDeConductores {
    private String nombre;
    private int horasPorDia;
    private int accidentes;

    public Conductor(String nombre, int horasPorDia, int accidentes) {
        this.nombre = nombre;
        this.horasPorDia = horasPorDia;
        this.accidentes = accidentes;
    }

    public String getNombre() {
        return nombre;
    }

    public int getHorasPorDia() {
        return horasPorDia;
    }

    public int getAccidentes() {
        return accidentes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setHorasPorDia(int horasPorDia) {
        this.horasPorDia = horasPorDia;
    }

    public void setAccidentes(int accidentes) {
        this.accidentes = accidentes;
    }

    @Override
    public String toString() {
        return "Conductor{" + "nombre=" + nombre + ", horasPorDia=" + horasPorDia + ", accidentes=" + accidentes + '}';
    }
    
}
