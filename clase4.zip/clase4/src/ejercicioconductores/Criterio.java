package ejercicioconductores;

public interface Criterio {
    Boolean aplicar(Conductor c);
}
