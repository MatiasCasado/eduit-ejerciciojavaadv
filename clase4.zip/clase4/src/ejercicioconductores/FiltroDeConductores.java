package ejercicioconductores;

import java.util.ArrayList;

public interface FiltroDeConductores {
    static ArrayList<Conductor> filtroCustom(ArrayList<Conductor> conductores, Criterio criterio) {
        ArrayList<Conductor> aux = new ArrayList<Conductor>();
        for(Conductor c: conductores){
            if (criterio.aplicar(c)) {
                aux.add(c);
            }
        }
        return aux;
    }
    static ArrayList<Conductor> sinAccidetes_deTresAcincoHoras(ArrayList<Conductor> conductores){
        return filtroCustom(conductores, 
                c -> ((c.getHorasPorDia() >= 3) && (c.getHorasPorDia() <= 5) && c.getAccidentes() == 0));        
    }
}
