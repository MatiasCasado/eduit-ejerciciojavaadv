package ejercicio1;

public class GUID {
    public static void main(String[] args) {
        System.out.println(java.util.UUID.randomUUID().toString());
    }
}
