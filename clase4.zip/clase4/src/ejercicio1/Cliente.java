package ejercicio1;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class Cliente {
    public static void main(String[] args) throws Exception {
        InetAddress IPAddress = InetAddress.getByName("localhost");
        byte[] sendData = new byte[512];
        byte[] recieveData = new byte[512];
        
        String mensajeEnviar = "GET";
        sendData = mensajeEnviar.getBytes();
        int longitudMensajeEnviar = mensajeEnviar.length();
        
        DatagramSocket clientSocket = new DatagramSocket();
        
        DatagramPacket sendPacket = new DatagramPacket(sendData, 
                longitudMensajeEnviar, IPAddress, 11000);
        
        DatagramPacket receivePacket = new DatagramPacket(recieveData, recieveData.length);
        
        System.out.println("Voy a enviar un paquete");
        clientSocket.send(sendPacket);
        
        Boolean seguirRecibiendo = true;
        
        while (seguirRecibiendo) {
            System.out.println("Espero recibir un paquete");
            clientSocket.receive(receivePacket);
        
            String recibidoEnFormatoString = 
                        new String(receivePacket.getData(), 0, receivePacket.getLength());
        
            System.out.println("Recibido en formato string: ");
            System.out.println(recibidoEnFormatoString);
            
            if (recibidoEnFormatoString.equals("FINSEQ")) {
                seguirRecibiendo = false;
            }
        }
        clientSocket.close();
    }
}
