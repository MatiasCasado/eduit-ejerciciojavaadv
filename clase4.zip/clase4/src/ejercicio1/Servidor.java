package ejercicio1;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Servidor {
    public static void main(String[] args) throws Exception {
        DatagramSocket serverSocket = new DatagramSocket(11000);
        byte[] receiveData = new byte[512];
        byte[] sendData = new byte[512];
        
        for (;;) {
            DatagramPacket receivePacket = 
                    new DatagramPacket(receiveData, receiveData.length);
            
            serverSocket.receive(receivePacket);
            
            String datoEnFormatoString = new String(receivePacket.getData(), 0, 
                    receivePacket.getLength());
            
            System.out.println("Recibido: ");
            System.out.println(datoEnFormatoString);
            System.out.println(receivePacket.getLength());
            
            InetAddress IPorigin = receivePacket.getAddress();
            int portOrigin = receivePacket.getPort();
            
            for (int x = 0; x <= 10; x++) {
                String uuid = java.util.UUID.randomUUID().toString();
                int largoMensaje = 0;
                
                if (x < 10) {
                    sendData = uuid.getBytes();
                    largoMensaje = 36;
                }
                else {
                    sendData = "FINSEQ".getBytes();
                    largoMensaje = 6;
                }
                
                DatagramPacket responsePacket = new DatagramPacket(sendData, 
                        largoMensaje, IPorigin, portOrigin);

                serverSocket.send(responsePacket);
                Thread.sleep(500);
            }
        }
    }
}
